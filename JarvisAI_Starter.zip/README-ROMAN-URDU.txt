JARVIS AI STARTER - ROMAN URDU GUIDE

Important:
- Ye APK abhi ZIP ke andar ready-made nahi hai. Ye Android project hai jo GitHub Actions se APK build kar sakta hai.
- AI jawab ke liye Gemini API key zaroori hai.
- API key app ke phone par local settings mein save hoti hai. Is starter ko personal testing ke liye rakhein; public app mein API key ko app ke andar rakhna secure nahi hota.
- Ye tumhari cloned voice nahi banata. Android ki installed Hindi TTS voice use karta hai.
- Speech recognition phone ke Google/Android speech service par depend kar sakta hai aur internet use kar sakta hai.

APK build karne ka tareeqa:
1. ZIP extract karo.
2. GitHub par nayi public ya private repository banao.
3. Is folder ke files repository mein upload karo, including hidden .github folder.
4. Repository ke Actions tab mein "Build Jarvis AI APK" workflow chalao.
5. Run successful hone par workflow ke Artifacts section se "JarvisAI-debug-apk" download karo.
6. ZIP artifact extract karke app-debug.apk install karo. Android unknown-app install permission pooch sakta hai.

Gemini API key:
- Google AI Studio mein apni API key banao; availability/limits Google ke account aur region par depend karte hain.
- App open karo, "API Key" dabao, apni key paste karke Save karo.
- API key kisi ko share mat karna.

Phone-only note:
GitHub mobile web par files upload karna thoda mushkil ho sakta hai. Ye starter APK ka direct download link nahi hai; build karna zaroori hai.
