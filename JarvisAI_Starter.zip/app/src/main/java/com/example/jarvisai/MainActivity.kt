package com.example.jarvisai

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Color
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var chat: TextView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private lateinit var apiKey: EditText
    private var readyToSpeak = false
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }
    private val history = JSONArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        showMessage("JARVIS", "Hello! Main Jarvis AI hoon. Pehle apni Gemini API key Settings mein add karo.")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 18)
            setBackgroundColor(Color.rgb(13, 18, 35))
        }
        val title = TextView(this).apply {
            text = "J A R V I S   A I"
            textSize = 24f
            setTextColor(Color.rgb(100, 220, 255))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 18)
        }
        root.addView(title)
        status = TextView(this).apply {
            text = "Ready"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 8)
        }
        root.addView(status)
        chat = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(14, 14, 14, 14)
            setBackgroundColor(Color.rgb(24, 31, 53))
            text = ""
        }
        val scroll = ScrollView(this)
        scroll.addView(chat)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply {
            hint = "Yahan message likho..."
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            textSize = 15f
            setSingleLine(false)
            minLines = 1
            maxLines = 3
            setBackgroundColor(Color.rgb(34, 43, 68))
            setPadding(12, 8, 12, 8)
        }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        val send = Button(this).apply {
            text = "Send"
            setOnClickListener { sendMessage() }
        }
        row.addView(send)
        root.addView(row)

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val mic = Button(this).apply {
            text = "🎙 Speak"
            setOnClickListener { startSpeechInput() }
        }
        val settings = Button(this).apply {
            text = "API Key"
            setOnClickListener { showApiKeyDialog() }
        }
        val clear = Button(this).apply {
            text = "Clear"
            setOnClickListener { chat.text = ""; history.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", "Continue our conversation.")))) }
        }
        buttons.addView(mic, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(settings, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(clear, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(buttons)
        setContentView(root)
    }

    private fun showApiKeyDialog() {
        val field = EditText(this).apply {
            hint = "Paste Gemini API key"
            setText(prefs.getString("api_key", ""))
            inputType = 129
        }
        AlertDialogBuilder.show(this, field) {
            val key = field.text.toString().trim()
            prefs.edit().putString("api_key", key).apply()
            status.text = if (key.isBlank()) "API key missing" else "API key saved on this phone"
            Toast.makeText(this, "API key saved on this phone", Toast.LENGTH_SHORT).show()
        }
    }

    private fun sendMessage() {
        val prompt = input.text.toString().trim()
        if (prompt.isEmpty()) return
        input.setText("")
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(input.windowToken, 0)
        showMessage("You", prompt)
        val key = prefs.getString("api_key", "") ?: ""
        if (key.isBlank()) {
            showMessage("JARVIS", "API Key button dabao aur apni Gemini API key add karo.")
            return
        }
        status.text = "Thinking..."
        thread {
            var answer: String
            try {
                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$key")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 30000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                }
                val body = JSONObject()
                    .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text",
                        "You are Jarvis, a helpful friendly AI assistant. Reply in the user's language. If the user writes Roman Urdu/Hindi, answer in simple Roman Urdu/Hindi."))))
                    .put("contents", JSONArray().put(JSONObject().put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                    .put("generationConfig", JSONObject().put("temperature", 0.7))
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                if (conn.responseCode !in 200..299) {
                    answer = "API error ${conn.responseCode}: " + try { JSONObject(response).toString() } catch (_: Exception) { response }
                } else {
                    val json = JSONObject(response)
                    answer = json.getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                }
                conn.disconnect()
            } catch (e: Exception) {
                answer = "Connection error: ${e.message ?: "Internet check karo"}"
            }
            runOnUiThread {
                status.text = "Ready"
                showMessage("JARVIS", answer)
                if (readyToSpeak) tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "jarvis-reply")
            }
        }
    }

    private fun showMessage(who: String, text: String) {
        chat.append("$who:\n$text\n\n")
    }

    private fun startSpeechInput() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS se bolo")
            }
            startActivityForResult(intent, 101)
        } catch (_: Exception) {
            Toast.makeText(this, "Speech recognition phone par available nahi hai", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101 && resultCode == RESULT_OK) {
            val result = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (!result.isNullOrEmpty()) {
                input.setText(result[0])
                sendMessage()
            }
        }
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale("hi", "IN")
            readyToSpeak = true
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}

object AlertDialogBuilder {
    fun show(activity: Activity, field: EditText, onSave: () -> Unit) {
        android.app.AlertDialog.Builder(activity)
            .setTitle("Gemini API Key")
            .setMessage("Personal use ke liye key is phone par save hogi. Is key ko kisi aur ko share mat karna.")
            .setView(field)
            .setPositiveButton("Save") { _, _ -> onSave() }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
